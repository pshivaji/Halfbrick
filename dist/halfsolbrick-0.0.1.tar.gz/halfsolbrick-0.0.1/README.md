# Three functions which you can use:

*csv_json : convert csv to json file 

*data_summary : Gives summary of data in various plots

*sql_insert : Convert in to sql insert statements