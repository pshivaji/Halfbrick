


                     codetestsol

                          |
                          |
                          |

                      functions

                          | 
                          |  
                          |
          ---------------------------------
          |               |               |      
          |               |               |
          |               |               |               
      csv_json       data_summary     sql_insert
                                                                
                                                                                


```bash
$ from codetestsol import functions
```


```bash
functions.csv_json("sample.csv")  
functions.data_summary ("sample.csv") 
functions.sql_insert("sample.csv") 
```
